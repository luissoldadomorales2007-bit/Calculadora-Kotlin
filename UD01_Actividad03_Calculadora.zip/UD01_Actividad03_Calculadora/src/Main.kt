fun main() {

    val calculos = Calculos()
    val depurar = Depurar()

    var opcion: Int

    do {

        println("1. Sumar")
        println("2. Restar")
        println("3. Multiplicar")
        println("4. Dividir")
        println("5. Calcular resto")
        println("6. Salir")
        print("Seleccione una opción: ")

        opcion = readLine()!!.toInt()

        if (depurar.opcionValida(opcion)) {

            if (opcion != 6) {

                print("Meta el primer número: ")
                val num1 = readLine()!!.toDouble()

                print("Meta el segundo número: ")
                val num2 = readLine()!!.toDouble()

                when (opcion) {

                    1 -> println("El resultado de la suma es: ${calculos.sumar(num1, num2)}")

                    2 -> println("El resultado de la resta es: ${calculos.restar(num1, num2)}")

                    3 -> println("El resultado de la multiplicación es: ${calculos.multiplicar(num1, num2)}")

                    4 -> {
                        if (depurar.divisorValido(num2)) {
                            println("El resultado de la división es: ${calculos.dividir(num1, num2)}")
                        } else {
                            println("ERROR. No se puede dividir entre cero.")
                        }
                    }

                    5 -> {
                        if (depurar.divisorValido(num2)) {
                            println("El resultado del resto es: ${calculos.resto(num1, num2)}")
                        } else {
                            println("ERROR. No se puede calcular el resto con cero.")
                        }
                    }
                }
            }

        } else {
            println("ERROR. Opción no válida.")
        }

        println()

    } while (opcion != 6)

    println("Programa finalizado.")
}