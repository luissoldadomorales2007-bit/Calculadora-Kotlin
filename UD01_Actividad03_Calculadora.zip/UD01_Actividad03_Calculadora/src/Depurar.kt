class Depurar {

    fun opcionValida(opcion: Int): Boolean {
        return opcion >= 1 && opcion <= 6
    }

    fun divisorValido(num2: Double): Boolean {
        return num2 != 0.0
    }
}